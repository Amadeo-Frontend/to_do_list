#

A entrega desse exercício
consiste em: 
#

• Crie uma aplicação de lista de tarefas. Nesta aplicação deve
haver um formulário com um campo para adicionar o nome da
tarefa e um botão para cadastrar a tarefa;

• Ao submeter o formulário adicione um elemento <li> dentro de
uma lista ordenada ou não;

• Ao clicar nos itens da lista adicione um efeito que aplique uma
linha em cima do texto (text-decoration: line-through);

• Utilize o jQuery para manipular os elementos e controlar os
eventos;

##